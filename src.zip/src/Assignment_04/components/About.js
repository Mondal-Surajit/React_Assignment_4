import React from 'react' 

export default class About extends React.Component {
    render() {
        return(
            <div>
                <h2>About: This application provides information about the products</h2>
            </div>
        );
    }
}