import React from 'react'
import { withRouter } from 'react-router-dom';
import {Link} from 'react-router-dom'

class ProductDetail extends React.Component {

        constructor(props) {
            super(props);
            // this.state = {
            //     modified : true
            // }
            this.authenticate(props.history);
        }

        authenticate(history) {
            let authenticated = window.confirm("Press OK to Login");
            if(!authenticated) {
                alert("Not Authorized, hence redirecting back...")
                history.replace("/")
            }
            else {
                alert("Authorized, hence proceeding ahead and displaying the details... ")
            }
        }

       

        render() {
            return(
                <div>
                    <h1>Product Details</h1>
                    <label>Product Name : {this.props.match.params.name}</label> 
                
                    <br/><br/>
                    <Link to='/products' >Back</Link>
                </div>

            );
        }

}

export default withRouter(ProductDetail)