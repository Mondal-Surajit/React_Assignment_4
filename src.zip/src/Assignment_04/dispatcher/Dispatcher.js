import { Dispatcher } from 'flux'
const dispatcher = new Dispatcher();
export default dispatcher;