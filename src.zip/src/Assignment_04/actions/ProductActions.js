import  Dispatcher  from '../dispatcher/Dispatcher'
import * as ActionTypes from '../constants/ActionTypes'
import ProductApi from '../data/ProductApi'

export default class ProductActions {
    static addProduct(product) {
        let newProduct = ProductApi.addProduct(product) ;
        console.log("Dispatching ADD PRODUCTS....")

        Dispatcher.dispatch({
            actionType : ActionTypes.ADD_PRODUCT ,
            product : newProduct 
        });
    }

    static viewProduct(name) {
        ProductApi.viewProduct(name);
        console.log("Dispatching View Product for name ..." + name);
        Dispatcher.dispatch({
            actionType : ActionTypes.VIEW_PRODUCT,
            name : name 
        })

    }
}