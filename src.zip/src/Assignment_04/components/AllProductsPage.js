import React from 'react'
import ProductsList from './ProductsList'
//import ProductApi from '../data/ProductApi';
import {Link} from 'react-router-dom'
import ProductStore from '../stores/ProductStore'
import InitializeActions from '../actions/InitializeActions'

export default class AllProductsPage extends React.Component {
    constructor(props) {
        super(props);
        this._onChange=this._onChange.bind(this);
        this.state = {
            products : ProductStore.getAllProducts()
        }
    }

    componentDidMount() {
        //ProductApi.getAllproduct(data => this.setState({products : data}))
        ProductStore.addChangeListener(this._onChange);
        InitializeActions.initProducts();
    }

    componentWillUnmount() {
        ProductStore.removeChangeListener(this._onChange);
    }

    _onChange() {
        this.setState({ products : ProductStore.getAllProducts()});
        console.log("All products page render "+ JSON.stringify(this.state.products));
    }
   

    render() {
        return(
            <>
                <h2>Products List</h2>
                <ProductsList products={this.state.products} />
                <br/>
                <Link to="/addProduct">Add Product</Link>
            </>
        );

    }
}