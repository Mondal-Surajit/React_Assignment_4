import ProductApi from '../data/ProductApi'
import  Dispatcher  from '../dispatcher/Dispatcher' 
import * as ActionTypes from '../constants/ActionTypes'

export default class InitializeActions {
    static initProducts() {

        ProductApi.getAllproduct(data =>
                Dispatcher.dispatch({
                    actionType: ActionTypes.INITIALIZE,
                    products: data
                })
        )
    }
}   