import React from 'react'
import {Link} from 'react-router-dom'

export default class Product extends React.Component {
    render() {
        const path = `/products/${this.props.name}`;
        return(
            <>
                <tr>
                    
                    <td><Link to={path}>{this.props.name}</Link></td>
                    <td>{this.props.quantity}</td>
                    <td>{this.props.children}</td>
                </tr>

                
            </>
        );
    }
}