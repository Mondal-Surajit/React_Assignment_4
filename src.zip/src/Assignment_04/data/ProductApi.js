import axios from 'axios' ;
import uuid from 'uuid/v4' ;
import _ from 'lodash'

export default class ProductApi {
    static getAllproduct(cb) {
        axios.get('http://localhost:4000/products')
        .then(response => cb(response.data))
        .catch(error => {throw error});
    }
    
    static addProduct(product) {
        product.id = uuid() ;
         
        axios.post('http://localhost:4000/products', (JSON.parse(JSON.stringify(product))))
        .then(res => {
            console.log(res);
            console.log(res.data);
          })
        .catch(error => {throw error});
      }

      static viewProduct(name) {
        _.get('http://localhost:4000/products', {prdname : name})
      }
}

